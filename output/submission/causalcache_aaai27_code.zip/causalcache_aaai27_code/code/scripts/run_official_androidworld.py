#!/usr/bin/env python3
"""Official-faithful AndroidWorld evaluation (paper reproduction harness).

# note (anonymous): 复现 X-PLUG/MobileAgent Mobile-Agent-v3.5 单体 gui_owl wrapper
# 的闭环行为,用于校准我们的绝对成功率(论文报 69.0)。与旧 v2.1 私有协议的差异见
# causalcache.policy.gui_owl_official 的模块注释。记忆预算映射 last_image = B + 1,
# 因此同一 harness 可直接跑 B=0/1/2/4/8 的消融而不改 prompt。
# 解析失败按官方转 UNKNOWN 动作:消耗一步、不再调模型、episode 继续;该步同样进
# 历史(文本 + 完整响应 + 它当时看的那张截图),因为它确实消耗了一步。
"""

from __future__ import annotations

import argparse
import json
import queue
import threading
import traceback
from pathlib import Path
from typing import Any, NamedTuple

from causalcache.policy.gui_owl_official import (
    OFFICIAL_PROTOCOL_ID,
    OfficialParseError,
    build_official_messages,
    extract_action_line,
    parse_official_output,
)
from causalcache.policy.gui_owl_v2 import gui_owl_v2_action_to_androidworld
from causalcache.policy.gui_owl_v2_1_runtime import GUIOwlV21OfficialToolsRuntime
from causalcache.set_utility_androidworld import PinnedOnlineOCRProvider
from scripts.build_sparse_history_dataset import official_response
from scripts.run_exploratory_closed_loop_episode import (
    EFFECTIVE_VISUAL_TOKENS_PER_IMAGE,
    _decode_png,
    _load_plan_instance,
)
from scripts.run_set_utility_androidworld_episode import (
    HTTPAndroidWorldEnvironment,
    write_episode_output_atomic,
)

OFFICIAL_MAX_NEW_TOKENS = 256


class CompletedStep(NamedTuple):
    """一个已消耗步的三元组:折叠用文本 / 保留轮完整响应 / 该步条件的截图。

    # note (anonymous): 审计第 4 条(P0)。``build_official_messages`` 现在按**位置**
    # 把末尾 kept 张截图与末尾 kept 条完整响应配对(image_i 后面紧跟 assistant_i),
    # 所以"文本历史 / 完整响应 / 高保真截图"三者必须严格等长且同序。旧代码用三个
    # 独立 list,而且 ``recent_images`` 只在动作真正执行后才 append:任何一次解析
    # 失败(UNKNOWN 步只 append 文本、不执行动作、不落图)都会让截图相对响应错位
    # 一格,且错位完全静默——build_official_messages 只检查 kept <= 步数,查不出来。
    # 改成"一个列表 + 单一 append 点"后,错位在结构上不可能发生:文本与完整响应取
    # 整个列表,截图取**同一个列表的后缀**,两边的截尾方式因此天然一致。
    """

    action_text: str
    full_response: str
    observation: Any


def history_full_response(raw: str, description: str, action: Any | None) -> str:
    """本步若落进保留轮,回填给模型的 assistant 内容。

    # note (anonymous): 审计第 4 条(P0)的另一半。保留轮必须是模型的**原始完整
    # 响应**(``Action: ...`` + ``<tool_call>{...}</tool_call>``),缺了就触发
    # gui_owl_official 的 fail-closed(那个收紧是对的,不能为了跑通而放宽)。
    # 来源优先级:
    #   1. 本步生成的 ``raw`` 逐字节原样——注意 step["raw_output"] 是截断到 600
    #      字符的诊断字段,绝不能拿它当历史来源;
    #   2. ``raw`` 空白(解码偶发空输出)但动作解析成功时,用与 target_text 同一个
    #      ``official_response()`` 反向重建,保证与训练语料格式逐字节一致;
    #   3. 连动作都解析不出来(UNKNOWN 步)时没有合法 tool call 可展示,只给 Action
    #      行——绝不伪造 tool_call 往上下文里塞一条假示范。
    """
    if isinstance(raw, str) and raw.strip():
        return raw
    if action is not None:
        return official_response(description, action.arguments())
    return f"Action: {description}"


class OfficialRuntime:
    """Wraps the frozen model with the official prompt/parse contract."""

    def __init__(self, base: GUIOwlV21OfficialToolsRuntime, torch: Any) -> None:
        self.base = base
        self.torch = torch
        self.lock = threading.Lock()

    def generate(self, messages: list[dict[str, Any]]) -> str:
        # note (anonymous): 绕开 v2.1 的单轮结构校验(官方是 user/assistant 多轮),
        # 编码参数与冻结路径逐字一致;贪心解码,遇 </tool_call> 停。
        base = self.base
        with self.lock:
            encoded = base.processor.apply_chat_template(
                [messages],
                tokenize=True,
                add_generation_prompt=True,
                return_dict=True,
                return_tensors="pt",
                padding=False,
            )
            encoded = (
                encoded.to(base.device)
                if hasattr(encoded, "to")
                else {k: v.to(base.device) for k, v in encoded.items()}
            )
            prompt_tokens = int(encoded["input_ids"].shape[1])
            tokens = base.generation_tokens
            with self.torch.inference_mode():
                out = base.model.generate(
                    **encoded,
                    do_sample=False,
                    max_new_tokens=OFFICIAL_MAX_NEW_TOKENS,
                    eos_token_id=tokens.tool_call_close_token_id,
                    pad_token_id=tokens.pad_token_id,
                    num_beams=1,
                    num_return_sequences=1,
                )
            new_tokens = out[:, prompt_tokens:]
            text = base.processor.batch_decode(
                new_tokens, skip_special_tokens=True
            )[0]
        return text


def run_official_episode(
    *,
    runtime: OfficialRuntime,
    ocr_provider: Any,
    args: argparse.Namespace,
    task_type: str,
    task_index: int,
    last_image: int,
    output: Path,
) -> dict[str, Any]:
    record = _load_plan_instance(
        args.ceiling_plan,
        task_type=task_type,
        task_index=task_index,
        allow_sealed=True,
    )
    instance = dict(record["instance"])
    environment = HTTPAndroidWorldEnvironment(
        base_url=args.base_url_current,
        instance=instance,
        ocr_provider=ocr_provider,
        observation_namespace=f"official:{task_type}:{task_index}",
        suite_seed=record["suite_seed"],
        task_combinations=record["task_combinations"],
    )
    summary: dict[str, Any] = {
        "protocol": OFFICIAL_PROTOCOL_ID,
        "task_type": task_type,
        "task_index": task_index,
        "last_image": last_image,
        "arm": f"official_B{last_image - 1}",
        "instance": instance,
        "steps": [],
        "infrastructure_failure": False,
    }
    history: list[CompletedStep] = []
    termination_reason = "step_budget_exhausted"
    unknown_steps = 0
    parse_failures = 0
    try:
        summary["environment_initialize"] = environment.initialize()
        # note (anonymous): 官方 suite_utils.run_task 不做"起始分必须为 0"的前置检查,
        # 只在 episode 结束时评分。我们原来的硬性检查把 *Verify 这类开局即满足的任务
        # 判成 infra 故障并踢出分母(2026-07-25 实测 6/116 局),与官方口径不符。
        # 现在只记录起始分并照常跑完,最终成绩仍由环境评定。
        summary["score_before"] = environment.score()
        summary["started_nonzero"] = summary["score_before"] != 0.0
        current = environment.screenshot()
        for step_index in range(instance["max_steps"]):
            # note (anonymous): last_image = B + 1 含当前截图,故历史保留窗口是
            # last_image - 1;窗口取 history 的**后缀**,与传进去的完整响应列表用的
            # 是同一条时间线,截尾方式因此不会分叉。
            keep = max(0, min(last_image - 1, len(history)))
            window = history[len(history) - keep :] if keep else []
            messages = build_official_messages(
                goal=instance["goal"],
                past_action_texts=[h.action_text for h in history],
                past_full_responses=[h.full_response for h in history],
                recent_images=[h.observation for h in window],
                current_image=current.image,
            )
            raw = runtime.generate(messages)
            # 本步模型实际条件其上的截图,先固定住:执行动作后 current 会被换掉
            observation = current.image
            step: dict[str, Any] = {
                "step_index": step_index,
                "raw_output": raw[:600],
                "high_fidelity_history_image_count": keep,
            }
            if not (isinstance(raw, str) and raw.strip()):
                step["full_response_reconstructed"] = True
            try:
                action, dropped = parse_official_output(raw)
                if dropped:
                    step["dropped_arguments"] = dropped
                step["canonical_action"] = {
                    "action": action.action,
                    **{k: v for k, v in action.arguments().items() if k != "action"},
                }
            except OfficialParseError as error:
                # 官方行为:UNKNOWN 动作,消耗一步,不重新调模型
                parse_failures += 1
                unknown_steps += 1
                step["parse_error"] = str(error)
                step["canonical_action"] = {"action": "UNKNOWN"}
                summary["steps"].append(step)
                # note (anonymous): UNKNOWN 步同样要落一条 history。它没执行动作、
                # 也没重新截图,所以本步的观测就是屏幕当前状态(下一步的 current 与它
                # 逐字节相同)——这正是当时真实发生的事:模型看着这张图吐了乱码。
                # 这里若不落图,截图就会比响应少一格,后面每一轮的历史配对全部错位。
                description = extract_action_line(raw) or "unknown action"
                history.append(CompletedStep(
                    description,
                    history_full_response(raw, description, None),
                    observation,
                ))
                continue
            description = extract_action_line(raw) or action.action
            history.append(CompletedStep(
                description,
                history_full_response(raw, description, action),
                observation,
            ))
            if action.action in ("terminate", "answer"):
                summary["steps"].append(step)
                termination_reason = "policy_terminated"
                break
            # note (anonymous): 官方 run_ma35 用 src_format="qwen-vl",其定义为
            # x/999*width —— 与本仓库 _pixel_coordinate 的 [0,999] 约定一致,
            # 故沿用同一转换,不存在二次归一化。
            aw = gui_owl_v2_action_to_androidworld(
                action,
                screen_width=int(current.metadata["width"]),
                screen_height=int(current.metadata["height"]),
            )
            step["androidworld_action"] = aw
            summary["steps"].append(step)  # 先记录再执行,便于诊断执行期崩溃
            step["execute_response"] = environment.execute(aw)
            current = environment.screenshot()
        summary["score_after"] = environment.score()
        summary["official_terminal_success"] = bool(summary["score_after"] > 0)
    except Exception as error:  # noqa: BLE001
        summary["infrastructure_failure"] = True
        summary["infrastructure_error"] = {
            "type": type(error).__name__,
            "message": str(error)[:400],
        }
        termination_reason = "infrastructure_exception"
        summary.setdefault("official_terminal_success", False)
        summary.setdefault("score_after", 0.0)
    finally:
        try:
            environment.tear_down()
        except Exception:  # noqa: BLE001
            pass
    summary["termination_reason"] = termination_reason
    summary["model_step_count"] = len(summary["steps"])
    summary["unknown_action_steps"] = unknown_steps
    summary["parse_failure_steps"] = parse_failures
    return summary


def worker(runtime, args, base_url, work, counters, lock) -> None:
    ocr_provider = PinnedOnlineOCRProvider.load(
        backend_config_path=args.repository_root
        / "code/configs/restoration_v2_ocr_backend.json",
        backend_manifest_path=args.repository_root
        / "data/manifests/restoration_v2_ocr_backend.json",
        model_dir=args.ocr_model_dir,
    )
    while True:
        try:
            task_type, task_index, last_image, attempt = work.get_nowait()
        except queue.Empty:
            return
        out = args.output_root / f"officialB{last_image - 1}-{task_type}-{task_index}.json"
        if out.exists():
            work.task_done()
            continue
        local = argparse.Namespace(**vars(args))
        local.base_url_current = base_url
        try:
            summary = run_official_episode(
                runtime=runtime, ocr_provider=ocr_provider, args=local,
                task_type=task_type, task_index=task_index,
                last_image=last_image, output=out,
            )
            if summary.get("infrastructure_failure") and attempt < args.infra_retries:
                work.put((task_type, task_index, last_image, attempt + 1))
                continue
            write_episode_output_atomic(out, summary)
            with lock:
                counters["done"] += 1
                counters["succ"] += int(summary["official_terminal_success"])
                n = counters["done"]
            print(json.dumps({
                "task": task_type, "idx": task_index, "B": last_image - 1,
                "success": summary["official_terminal_success"],
                "steps": summary["model_step_count"],
                "unknown": summary["unknown_action_steps"],
                "done": n, "succ_rate": round(counters["succ"] / n, 3),
            }), flush=True)
        except Exception:
            if attempt < args.infra_retries:
                work.put((task_type, task_index, last_image, attempt + 1))
                continue
            with lock:
                counters["errored"] += 1
            print(json.dumps({"error": traceback.format_exc(limit=4)}), flush=True)
        finally:
            work.task_done()


def main() -> None:
    p = argparse.ArgumentParser()
    p.add_argument("--repository-root", type=Path, required=True)
    p.add_argument("--model-dir", type=Path, required=True)
    p.add_argument("--ocr-model-dir", type=Path, required=True)
    p.add_argument("--ceiling-plan", type=Path, required=True)
    p.add_argument("--plan-instances", type=Path, required=True)
    p.add_argument("--output-root", type=Path, required=True)
    p.add_argument("--device", required=True)
    p.add_argument("--base-url", action="append", required=True)
    p.add_argument("--last-image", type=int, default=5)
    p.add_argument("--infra-retries", type=int, default=3)
    args = p.parse_args()
    args.output_root.mkdir(parents=True, exist_ok=True)

    import torch

    base = GUIOwlV21OfficialToolsRuntime(
        model_dir=args.model_dir,
        expected_snapshot_manifest=(
            args.repository_root / "code/configs/gui_owl_1_5_8b_snapshot.json"
        ),
        device=args.device,
        target_effective_visual_tokens_per_image=EFFECTIVE_VISUAL_TOKENS_PER_IMAGE,
    )
    base.model.eval()
    runtime = OfficialRuntime(base, torch)

    instances = json.loads(args.plan_instances.read_text(encoding="utf-8"))
    work: queue.Queue = queue.Queue()
    for inst in instances:
        work.put((inst["task_type"], int(inst["task_index"]), args.last_image, 0))
    print(json.dumps({"total": work.qsize(), "last_image": args.last_image,
                      "B": args.last_image - 1, "emulators": len(args.base_url)}), flush=True)
    counters = {"done": 0, "succ": 0, "errored": 0}
    lock = threading.Lock()
    threads = [
        threading.Thread(target=worker,
                         args=(runtime, args, u, work, counters, lock), daemon=True)
        for u in args.base_url
    ]
    for t in threads:
        t.start()
    for t in threads:
        t.join()
    print(json.dumps({"complete": counters}), flush=True)


if __name__ == "__main__":
    main()
